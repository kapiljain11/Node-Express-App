// server.js
const express = require('express');
const path = require('path');
const app = express();
const PORT = 3000;

// Set EJS as the view engine
app.set('view engine', 'ejs');
// Set the directory where EJS templates are located
app.set('views', path.join(__dirname, 'views'));

// Define a route to render the index.ejs file
app.get('/', (req, res) => {
  const pageTitle = 'EJS Express Example';
  const userName = 'Alice';
  const items = ['Item A', 'Item B', 'Item C'];

  res.render('index', { 
    title: pageTitle,
    name: userName,
    listItems: items
  });
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});